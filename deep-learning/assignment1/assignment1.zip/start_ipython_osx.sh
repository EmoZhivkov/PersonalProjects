# Assume the virtualenv is called .env

cp frameworkpython venv/bin
venv/bin/frameworkpython -m IPython notebook
